function checkAll(frm_member,act_del,obj_ad)
{
	var val; 
    val=obj_ad;
	chkarr = frm_member.elements["chk_act[]"];
	var i=0;
	for( i=0 ; i<chkarr.length ; i++)
	{
		chkarr[i].checked=val;
	} 		
}


function activate_confirm(frm_member)
{
	chkarr=frm_member.form.elements['chk_act[]'];
 	var i=0;
 	var temp=0;
    for( i=0 ; i<chkarr.length ; i++)
    {
    	if (chkarr[i].checked==true)
		{
		temp=1;
		break;
		}
    } 
	if(temp==0)
	{
		alert("Please Select at least one Record. ");
		return false;
	}
	var app_yes= confirm("Do you want to activate record?");
	if (app_yes==true)
	{
		return true;
	}
	else
	{
		$('input:checkbox').attr('checked', false);
		return false;
	}
}

function deactivate_confirm(frm_member)
{
	chkarr=frm_member.form.elements['chk_act[]'];
	var i=0;
	var temp=0;
    for( i=0 ; i<chkarr.length ; i++)
    {
    	if (chkarr[i].checked==true)
		{
		temp=1;
		break;
		}
    } 
	if(temp==0)
	{
		alert("Please Select at least one Record. ");
		return false;
	}
	var act_yes= confirm("Do you want to deactivate record?");
	if (act_yes==true)
	{
		return true;
	}
	else
	{
		$('input:checkbox').attr('checked', false);	
		return false;
	}
}
function delete_confirm(frm_member)
{
	chkarr=frm_member.form.elements['chk_act[]'];
 	var i=0;
	var temp=0;
    for( i=0 ; i<chkarr.length ; i++)
    {
    	if (chkarr[i].checked==true)
		{
		temp=1;
		break;
		}
    } 
	if(temp==0)
	{
		alert("Please Select at least one Record. ");
		return false;
	}
	var act_yes= confirm("Do you want to delete record?");
	if (act_yes==true)
	{
		return true;
	}
	else
	{
		$('input:checkbox').attr('checked', false);
		return false;
	}
}
function challan_confirm(frm_member)
{
	chkarr=frm_member.form.elements['chk_act[]'];
 	var i=0;
	var temp=0;
    for( i=0 ; i<chkarr.length ; i++)
    {
    	if (chkarr[i].checked==true)
		{
		temp=1;
		break;
		}
    } 
	if(temp==0)
	{
		alert("Please Select at least one Record. ");
		return false;
	}
	var act_yes= confirm("Do you want to statement for selected records?");
	if (act_yes==true)
	{
		return true;
	}
	else
	{
		$('input:checkbox').attr('checked', false);
		return false;
	}
}
function delete_single()
{
   var del_yes= confirm("Do you want to delete record?");
   if (del_yes==true){
   		 return true;
   }
   else
	  return false;
}
function numeric_only(e)
{	
	var unicode = e.charCode ? e.charCode : e.keyCode;
	if((unicode >= 46 && unicode <= 57 && unicode!=47) || unicode==8)
		return true;
	else
		return false;
}
setTimeout(function(){ $(".alert.alert-success").hide('slow'); }, 3000);