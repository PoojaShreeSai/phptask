<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8" />
   <title>Forgot Password</title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<link rel="icon" href="<?php echo base_url() ?>images/favicon.png" type="image/x-icon">
   <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style-responsive.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style-default.css" rel="stylesheet" id="style_color" />
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="lock">
    <div class="lock-header">
        <!-- BEGIN LOGO -->
        <a class="center" id="logo">
          <!-- <img src="<?php echo base_url(); ?>images/logo.png" title="ITdeskQ" alt="ITdeskQ"/> -->
        </a>
        <!-- END LOGO -->
    </div>
    <?php 
    echo form_open('forgot');
    ?>
    <div class="login-wrap">
       <div class="metro double-size red">
            <div class="locked lock-forgot">
                <i class="icon-lock"></i>
                <span>Forgot Password</span>
            </div>
        </div>
        <div class="metro double-size green">
            <div class="input-append lock-input">
                <input type="text" name="email" placeholder="Email Address" value="<?php echo $this->input->post("email"); ?>">
            </div>
        </div>
        <div class="metro double-size terques login">
            <button type="submit" name="submit" class="btn login-btn">Submit<i class=" icon-long-arrow-right"></i></button>
        </div>
        <div class="login-footer">
            <div style="font-size: 18px; margin-left: -13px;font-weight: bold"><?php if(form_error('email')) echo form_error('email');else if($err_msg) echo $err_msg; ?></div>
            <?php if($msg!="") { ?>
            	<div style="font-size: 18px; margin-left: -13px;font-weight: bold"><?php echo $msg ?></div>
            <?php } ?>
            <div class="forgot-hint pull-right">
                <a id="forget-password" class="" href="<?php echo base_url()?>">Go To Login</a>
            </div>
        </div>
    </div>
    <?php echo form_close(); ?>
</body>
<!-- END BODY -->
</html>