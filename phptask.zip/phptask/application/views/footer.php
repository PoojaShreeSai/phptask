
	 </div>
   </div>
</div>   
<?php defined('BASEPATH') OR exit('No direct script access allowed');
$url		=	current_url();
$parts		=	explode('/', $url);
$page		=	$parts[4];
$hideSideBar = $_GET['hideSideBar'];
$hideSideBar =  end($parts);
 

?> 
<!-- BEGIN FOOTER -->
   <div id="footer" <?php if($hideSideBar == 'hideSideBar') {?> style="display:none;" <?php  }?>>© Copyright <?php echo date("Y"); ?>. All rights reserved.</div>
   <!-- END FOOTER -->
    <!-- BEGIN JAVASCRIPTS -->
   <!-- Script For Side Slim ScrollBar  -->
   <script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.nicescroll.js" type="text/javascript"></script>
   <!-------For Logout dropdown---------->
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
   <!-- ie8 fixes -->
   <!--[if lt IE 9]>
   <script src="js/excanvas.js"></script>
   <script src="js/respond.js"></script>
   <![endif]-->
   <!--- Script Required For Serial Number In Table ---->
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap-daterangepicker/date.js"></script>
   <!-- Script For Dynamic Tables -->
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/data-tables/DT_bootstrap.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>js/dynamic-table.js"></script>
   <!--common script for all pages-->
   <script src="<?php echo base_url(); ?>js/common-scripts.js"></script>
   <script src="<?php echo base_url(); ?>js/script.js"></script>
   <!-- END JAVASCRIPTS -->   
   
   
</body>
<!-- END BODY -->
</html>
</body>
<!-- END BODY -->
</html>