<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
$session	=	$this->session->all_userdata();
$admin_id	=	$session['SHREeKrushI_iD'];
$usertpdb	=	$session['SHREeKrushI_uSEr'];
$url		=	current_url();
$parts		=	explode('/', $url);
$page		=	$parts[4];
$hideSideBar = $_GET['hideSideBar'];
$hideSideBar =  end($parts);
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8"/>
   <title>Portal | No call is too small</title>  
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <link rel="icon" href="<?php echo base_url() ?>images/favicon.png" type="image/x-icon">
   <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style-responsive.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style-default.css" rel="stylesheet" id="style_color" />
   <!-- <link href="<?php echo base_url(); ?>css/style-green.css" rel="stylesheet" id="style_color" /> -->
   <link href="<?php echo base_url(); ?>css/modality.css" rel="stylesheet">
   <link href="<?php echo base_url(); ?>css/scrollcss.css" rel="stylesheet">
   <script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-1.8.3.min.js"></script>
   <link rel="STYLESHEET" type="text/css" href="<?php echo base_url(); ?>css/pwdwidget.css" />
   <script src="<?php echo base_url(); ?>js/pwdwidget.js" type="text/javascript"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.js" type="text/javascript"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js" type="text/javascript"></script>
   <link rel="STYLESHEET" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css" />
   <link rel="STYLESHEET" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.css" />
   <link rel="STYLESHEET" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.css.map" />
</head>
<?php  if($hideSideBar == 'hideSideBar') {?>
<style>
	.fixed-top #container{
		margin-top : 0px!important;
	}
	#main-content{
		margin-left : 0px!important;
	}
	.widget{
		border:none!important;
	}
	</style>
<?php } ?>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="fixed-top">
   <!-- BEGIN HEADER -->
   <div id="header" class="navbar navbar-inverse navbar-fixed-top" <?php if($hideSideBar == 'hideSideBar') {?> style="display:none;" <?php  }?>>
       <!-- BEGIN TOP NAVIGATION BAR -->
       <div class="navbar-inner">
           <div class="container-fluid">
               <!--BEGIN SIDEBAR TOGGLE-->
               <div class="sidebar-toggle-box hidden-phone">
                   <div class="icon-reorder"></div>
               </div>
               <!--END SIDEBAR TOGGLE-->
               <!-- BEGIN LOGO -->
               <a class="brand" href="<?php echo base_url(); ?>">
                   <!-- <img src="<?php echo base_url(); ?>images/logo.png" title="SHREeKrushI" alt="SHREeKrushI"/> -->
               </a>
               <!-- END LOGO -->
               <!-- BEGIN RESPONSIVE MENU TOGGLER -->
               <a class="btn btn-navbar collapsed" id="main_menu_trigger" data-toggle="collapse" data-target=".nav-collapse">
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="arrow"></span>
               </a>
               <!-- END RESPONSIVE MENU TOGGLER -->
               <div class="top-nav ">
                   <ul class="nav pull-right top-menu" >                      
                       <!-- BEGIN USER LOGIN DROPDOWN -->
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                               <img src="<?php echo base_url(); ?>images/avatar-mini.png" alt="">
                               <span class="username"><?php echo ucwords($this->session->userdata['SHREeKrushI_aDmiNName']); ?></span>
                               <b class="caret"></b>
                           </a>                          
                           <ul class="dropdown-menu extended logout">
                           	   <li><a href="<?php echo base_url(); ?>welcome/logout"><i class="icon-key"></i> Log Out</a></li>
                           </ul>
                       </li>
                       <!-- END USER LOGIN DROPDOWN -->
                   </ul>
                   <!-- END TOP NAVIGATION MENU -->
               </div>
           </div>
       </div>
       <!-- END TOP NAVIGATION BAR -->
   </div>
   <!-- END HEADER -->
   <!-- BEGIN CONTAINER -->
   <div id="container" class="row-fluid">
   	   <!-- BEGIN SIDEBAR -->
      <div class="sidebar-scroll" <?php if($hideSideBar == 'hideSideBar') {?> style="display:none;" <?php  }?>>
        <div id="sidebar" class="nav-collapse collapse">
         <!-- END RESPONSIVE QUICK SEARCH FORM -->
         <!-- BEGIN SIDEBAR MENU -->
          <ul class="sidebar-menu">
          	  
              <li class="sub-menu <?php if($page=="category") { ?> active<?php } ?>">
                  <a href="<?php echo base_url(); ?>category">
                      <i class="icon-group"></i>
                      <span>Manage Category </span>
                  </a>                 
              </li>
               
              <li class="sub-menu <?php if($page=="product") { ?> active<?php } ?>">
                  <a href="<?php echo base_url(); ?>product">
                      <i class="icon-glass"></i>
                      <span>Manage Product</span>
                  </a>                 
              </li>
          </ul>
         <!-- END SIDEBAR MENU -->
      	</div>
      </div>
      <!-- END SIDEBAR -->
      <!-- BEGIN PAGE -->  
      <div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">