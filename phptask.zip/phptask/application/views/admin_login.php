<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
//echo md5('Admin123');
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8" />
   <title>Login Form</title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<link rel="icon" href="<?php echo base_url() ?>images/favicon.png" type="image/x-icon">
   <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style-responsive.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style-default.css" rel="stylesheet" id="style_color" />
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="lock">
    <div class="lock-header">
        <!-- BEGIN LOGO -->
        <a class="center" id="logo" href="<?php echo base_url();?>welcome">
         <!-- <img src="<?php echo base_url(); ?>images/logo.png" title="ITdeskQ" alt="ITdeskQ"/> -->
        </a>
        <!-- END LOGO -->
    </div>
    <?php echo form_open('welcome');
    
    ?>
    <div class="login-wrap">
        <div class="metro single-size red">
            <div class="locked">
                <i class="icon-lock"></i>
                <span>Login</span>
            </div>
        </div>
        <div class="metro double-size green">
            <div class="input-append lock-input">
                <input type="text" name="username" placeholder="Username" value="<?php echo $this->input->post('username') ?>">
            </div>
        </div>
        <div class="metro double-size yellow">
            <div class="input-append lock-input">
                <input type="password" name="passw" placeholder="Password" value="">
            </div>
        </div>
        <div class="metro single-size terques login">
            <button type="submit" name="submit" class="btn login-btn">
                Login
                <i class="icon-long-arrow-right"></i>
            </button>
        </div>
        <div class="login-footer">
        	<div class="error" style="font-size: 18px; margin-left: 30px;font-weight: bold"> <?php echo form_error('username'); ?> </div>
        	<div class="error" style="font-size: 18px; margin-left: 30px;font-weight: bold"> <?php echo form_error('passw'); ?> </div>
        	<div class="error" style="font-size: 18px; margin-left: 30px;font-weight: bold"> <?php echo $err_msg; ?> </div>
            <div class="forgot-hint pull-right">
                <a id="forget-password" class="" href="<?php echo base_url() ?>registration">Signup?</a>
            </div>
        </div>
    </div>
    <?php echo form_close(); ?>
</body>
<!-- END BODY -->
</html>