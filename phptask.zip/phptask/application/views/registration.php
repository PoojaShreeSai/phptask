<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8" />
   <title>Registration Form</title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<link rel="icon" href="<?php echo base_url() ?>images/favicon.png" type="image/x-icon">
   <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style-responsive.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>css/style-default.css" rel="stylesheet" id="style_color" />
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="lock">
    <div class="lock-header">
        <!-- BEGIN LOGO -->
        <a class="center" id="logo" href="<?php echo base_url();?>registration">
         <!-- <img src="<?php echo base_url(); ?>images/logo.png" title="ITdeskQ" alt="ITdeskQ"/> -->
        </a>
        <!-- END LOGO -->
    </div>
    <?php echo form_open('registration');
    
    ?>
    <div class="login-wrap">
    	<?php if($message) { ?>
		                        <div class="alert alert-success">
		                           <button class="close" data-dismiss="alert">�</button>
		                           <strong><?php echo $message; ?></strong>
		                        </div>
		                    	<?php } ?>
        <div class="row">
<div class="metro single-size">
            
        </div>
        <div class="metro double-size green">
            <div class="input-append lock-input">
                <input type="text" name="email" placeholder="Email" value="<?php echo $this->input->post('email') ?>">
            </div>
        </div>
        <div class="metro double-size red">
            <div class="input-append lock-input">
                <input type="text" name="username" placeholder="Username" value="<?php echo $this->input->post('username') ?>">
            </div>
        </div>
      	</div>
      	<div class="row">
      		<div class="metro single-size">
            
        </div>
        <div class="metro double-size yellow">
            <div class="input-append lock-input">
                <input type="password" name="passw" placeholder="Password" value="">
            </div>
        </div>
        <div class="metro double-size terques login">
            <button type="submit" name="submit" class="btn login-btn">
                Signup
                <i class="icon-long-arrow-right"></i>
            </button>
        </div>
      </div>
        <div class="login-footer">
        	<?php if(form_error('email')) { ?>
        	<div class="error" style="font-size: 18px;font-weight: bold"> <?php echo form_error('email'); ?> </div>
        	<?php } else if(form_error('username')) { ?>
        	<div class="error" style="font-size: 18px;font-weight: bold"> <?php echo form_error('username'); ?> </div>
        	<?php } else if(form_error('passw')) { ?>
        	<div class="error" style="font-size: 18px;font-weight: bold"> <?php echo form_error('passw'); ?> </div>
        	<?php } ?>
        	
            <div class="forgot-hint">
                <a id="forget-password" class="" href="<?php echo base_url() ?>welcome">Login</a>
            </div>
        </div>
    </div>
    <?php echo form_close(); ?>
</body>
<!-- END BODY -->
</html>