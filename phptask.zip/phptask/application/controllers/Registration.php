<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Registration extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('comman_model');
	}
	public function index()
	{
		$data	=	$this->comman_model->is_logged_in();
		
		if($data!=true)
		{
			$this->form_validation->set_rules('email','email','trim|required|callback_alreadyemail',array('required'=>"Please enter email","alreadyemail"=>"This email address already exists, please try another email address"));
			$this->form_validation->set_rules('username', 'Username', 'trim|required|callback_alreadyuser',array('required' => 'Please enter username',"alreadyuser"=>"This username already exists, please try another username"));
			$this->form_validation->set_rules('passw', 'Password', 'required|min_length[8]|alpha_numeric|callback_validatePassword',array('required' => 'Please enter password','min_length' => "Password should have minimum 8 characters","alpha_numeric" => "Please enter alpha numeric password","validatePassword" => "Please enter alpha numeric password"));
		
			if($this->form_validation->run() !== FALSE){
				$insert_data = array();
				$insert_data['admin_email'] = $this->input->post('email');
				$insert_data['admin_name'] = $this->input->post('username');
				$insert_data['admin_password'] = md5($this->input->post('passw'));
				$insert_data['date_added'] = date("Y-m-d H:i:s");
				$this -> comman_model -> insert_data($insert_data,'admin');
				$data['message'] = "Registration successful";
				$this->output->set_header('refresh:3; url='.base_url()."welcome");
							
			}
			$this->load->view('registration',$data);
		}
		else
		{
			redirect(base_url().'/product');
		}
	}
	public function alreadyemail()
	{
		$res	=	$this->comman_model->alreadyemail($this->input->post('email'));
		return $res;
	}
	public function alreadyuser()
	{
		$res	=	$this->comman_model->alreadyuser($this->input->post('username'));
		return $res;
	}
	public function validatePassword($str)
	{
	   if (preg_match('#[0-9]#', $str) && preg_match('#[a-zA-Z]#', $str)) {
	     return TRUE;
	   }
	   return FALSE;
	}
	
}