<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Forgot extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('forgot_model');
	}
	public function index(){
		$data	=	$this->forgot_model->is_logged_in();
		if($data!=true)
		{			
			$this->form_validation->set_rules('email','Email','trim|required|valid_email',array('required' => 'Please enter email address','valid_email' => 'Please enter valid email address'));
			
			if($this->form_validation->run() != FALSE)
			{
				$result_user = $this->forgot_model->user($this->input->post('email'));
				
				if(!$result_user)
					$data['err_msg']	= "Email address does not exists";
				else
				{
					$result			=	$this->forgot_model->email(); // admin id 1
					$pass			=	random_string('alnum', 8);
					$admin			=	$result['admin_name'];
					$login_url		=	base_url()."";
					$to				=	$this->input->post('email');
					$from			=	$result['admin_email'];   // admin id 1
					$subject		=	"ITdeskQ : Forgot Password Mail";
					$message		=	'<table align="left" border="0" cellpadding="0" cellspacing="0">
										<tr><td><b>Dear User,</b></td></tr>
										<tr><td>&nbsp;</td></tr>
										<tr><td>We received a request to reset the password associated with this e-mail address.</td></tr>
										<tr><td>&nbsp;</td></tr>
										<tr><td><b>Your login details:</td></tr>
										<tr><td>&nbsp;</td></tr>
										<tr><td><b>Username : </b>'.$result_user['admin_name'].' </td></tr>
										<tr><td><b>New Password : </b>'.$pass.' </td></tr>
										<tr><td>&nbsp;</td></tr>
										<tr><td>After login change your password this is highly recommend</td></tr>
										<tr><td>&nbsp;</td></tr>
										<tr><td><a href="'.$login_url.'" target="_blank">Click Here</a> to login</td></tr>
										<tr><td>&nbsp;</td></tr>
										<tr><td><b>Regards,</td></tr>
										<tr><td>ITdeskQ Team</td></tr>
										</td></tr>
										</table>';		
										$this->email->from($from, ucwords($admin));
										$this->email->to($to); 
										$this->email->subject($subject);
										$this->email->message($message);
										$this->email->set_mailtype("html");	
										if($this->email->send())
										{
											$this->forgot_model->updaterow($to,$pass);
											$data['msg']	=	"If the e-mail address you entered is associated with a admin account in our records, you will receive an e-mail from us with username and password. If you don't receive this e-mail, please check your junk mail folder.";
										}
										else
										     $data['msg']	=	"Email not sent please try again.";
				}
				$this->load->view('forgot',$data);
			}
			else
				$this->load->view('forgot');
		}
		else
		{
			$this->load->view('header',$data);
			$this->load->view('index',$data);
			$this->load->view('footer');
		}
	}
}