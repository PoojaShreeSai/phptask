<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Welcome extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('comman_model');
	}
	public function index()
	{
		$data	=	$this->comman_model->is_logged_in();
		
		if($data!=true)
		{
			$this->form_validation->set_rules('username', 'Username', 'required',array('required' => 'Please enter username'));
			$this->form_validation->set_rules('passw', 'Password', 'required',array('required' => 'Please enter password'));
		
			if($this->form_validation->run() == FALSE)
				$this->load->view('admin_login');
			else 
			{
				$unm  		=	$this->input->post('username');
				$pwd  		=	$this->input->post('passw');
				$result 	=	$this->comman_model->get_admin($unm,$pwd);
				$id			=	$result[0]['id'];
				$user_type	=	$result[0]['user_role'];
				
				if($result == 0)
				{
					$data['err_msg']	= "Username or password is incorrect";
					$this->load->view('admin_login',$data);
				}
				else 
				{
					$newdata = array(
			                   'SHREeKrushI_iD'  		=> $result[0]['id'],
			                   'SHREeKrushI_aDmiNName'  => $result[0]['admin_name'],
			                   'SHREeKrushI_LOg'		=> TRUE,
			                   'SHREeKrushI_uSEr'		=> $user_type
	               			   );
					$this->session->set_userdata($newdata);
					$this ->comman_model->update_record(array('login_time'=>date("Y-m-d H:i:s")),$id,'admin');
					redirect(base_url());
				}
			}
		}
		else
		{
			redirect(base_url().'/product');
		}
	}
	public function logout()
	{
		$var = $this->session->userdata;
		$this -> comman_model -> update_record(array('logoff_time'=>date("Y-m-d H:i:s")),$var['SHREeKrushI_iD'],'admin');
		$this->session->unset_userdata('SHREeKrushI_iD');
		$this->session->unset_userdata('SHREeKrushI_aDmiNName');
		$this->session->unset_userdata('SHREeKrushI_LOg');
		$this->session->unset_userdata('SHREeKrushI_uSEr');
		redirect(base_url());
	}
}